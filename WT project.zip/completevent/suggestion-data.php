<?php
// Connect to the database
try {
    $db = new PDO('mysql:host=localhost;dbname=events', 'root', '12345');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Could not connect to the database: ' . $e->getMessage());
}

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $suggestion = $_POST['suggestion'];

    // Use placeholders in the SQL query to prevent SQL injection
    $query = "INSERT INTO suggestion (name, email, suggestion) VALUES ($name, $email, suggestion)";
    $stmt = $db->prepare($query);

    // Bind parameters
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':suggestion', $suggestion);

    try {
        $stmt->execute();
        echo "Suggestion submitted successfully!";
        // Redirect to thankyou.php after successful submission
        header('Location: thankyou.php');
        exit;
    } catch (PDOException $e) {
        echo "Feedback submission failed. Please try again. Error: " . $e->getMessage();
    }
}
?>

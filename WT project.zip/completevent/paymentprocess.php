<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "12345";
$dbname = "events";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Escape values to prevent SQL injection
$clientName = $conn->real_escape_string($_POST['client_name']);
$clientEmail = $conn->real_escape_string($_POST['client_email']);
$clientPhone = $conn->real_escape_string($_POST['client_phone']);

// Insert client information into the database
$sqlClient = "INSERT INTO clients (name, email, phone) VALUES ('$clientName', '$clientEmail', '$clientPhone')";

if ($conn->query($sqlClient) !== TRUE) {
    echo "Error: " . $sqlClient . "<br>" . $conn->error;
    exit;
}

// Retrieve the client ID
$clientID = $conn->insert_id;

// Retrieve selected venue, food, and ambiance information
$selectedVenue = $conn->real_escape_string($_POST['venue_name']); // Change 'name' to the actual name of the form field
$selectedFood = $conn->real_escape_string($_POST['food_name']);   // Change 'name' to the actual name of the form field
$selectedAmbiance = $conn->real_escape_string($_POST['ab_name']); // Change 'name' to the actual name of the form field
$selectedVenueCost = $conn->real_escape_string($_POST['venue_cost']); // Change 'name' to the actual name of the form field
$selectedFoodCost = $conn->real_escape_string($_POST['food_cost']);   // Change 'name' to the actual name of the form field
$selectedAmbianceCost = $conn->real_escape_string($_POST['ab_cost']);
$date = $conn->real_escape_string($_POST['event_date']);
$time = $conn->real_escape_string($_POST['event_time']);// Change 'name' to the actual name of the form field

$totalCost = $selectedVenueCost + $selectedFoodCost + $selectedAmbianceCost;



$sqlPayment = "INSERT INTO payments (client_id, venue, food, ambiance, total_cost,dt_date,dt_time) 
                   VALUES ('$clientID', '$selectedVenue', '$selectedFood', '$selectedAmbiance', $totalCost,'$date','$time')";

    if ($conn->query($sqlPayment) === TRUE) {
        echo '<script type="text/javascript">';
        echo 'alert("Payment Successful!");';
        echo 'window.location.href = "thankyou.php";'; // Redirect to thank_you.php or another success page
        echo '</script>';
        exit;
    } else {
        echo "Error: " . $sqlPayment . "<br>" . $conn->error;
    }
// Close the connection
$conn->close();
?>

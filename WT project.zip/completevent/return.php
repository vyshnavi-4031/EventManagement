<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wedding Planner - Choose Ambiance</title>
    <style>
    body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
}

header {
    background-color: #333;
    color: #fff;
    padding: 1em;
    text-align: center;
}

section {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    padding: 20px;
}

.ambiance {
    width: 30%;
    margin: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s;
    cursor: pointer;
}

.ambiance:hover {
    transform: scale(1.05);
}

.ambiance img {
    width: 100%;
    height: auto;
}
</style>

</head>
<body>

    <header>
        <h1>Choose ambiance</h1>
    </header>

    <section id="ambianceTab" class="tab active">

        <!-- Add the form to submit venue details -->
        <form id="ambianceForm" action="ambiance_db.php" method="GET" style="display: none;">
            <input type="hidden" id="selectambiance" name="ambiance" value="">
            <input type="hidden" id="selectCost" name="cost" value="">
            <input type="hidden" id="selectImage" name="image" value="">
        </form>

        <div class="ambiance" onclick="selectambiance('ambiance A', 50000, 'photos/gift1.jpg')">
            <img src="photos/gift1.jpg" alt="ambiance A">
            <h3>return A</h3>
            <p>$50000</p>
        </div>

        <div class="ambiance" onclick="selectambiance('ambiance B', 70000, 'photos/gift2.jpg')">
            <img src="photos/gift2.jpg" alt="ambiance B">
            <h3>return B</h3>
            <p>$70000</p>
        </div>
        <div class="ambiance" onclick="selectambiance('ambiance C', 50000, 'photos/gift3.jpg')">
            <img src="photos/gift3.jpg" alt="ambiance C">
            <h3> return C</h3>
            <p>$50000</p>
        </div>

        <div class="ambiance" onclick="selectambiance('ambiance D', 70000, 'photos/gift4.jpg')">
            <img src="photos/gift4.jpg" alt="ambiance D">
            <h3>return  D</h3>
            <p>$70000</p>
        </div>
        <div class="ambiance" onclick="selectambiance('ambiance E', 50000, 'photos/gift5.jpg')">
            <img src="photos/gift5.jpg" alt="ambiance E">
            <h3>return  E</h3>
            <p>$50000</p>
        </div>

        <div class="ambiance" onclick="selectambiance('ambiance F', 70000, 'photos/gift6.jpg')">
            <img src="photos/gift6.jpg" alt="ambiance F">
            <h3>return F</h3>
            <p>$70000</p>
        </div>
        
    </section>

    <script>
        function selectambiance(ambiance, cost, imagePath) {
            // Set the selected venue, cost, and image path values in the form
            document.getElementById('selectambiance').value = ambiance;
            document.getElementById('selectCost').value = cost;
            document.getElementById('selectImage').value = imagePath;

            // Submit the form to redirect to food.php
            document.getElementById('ambianceForm').submit();
        }
    </script>
</body>
</html>
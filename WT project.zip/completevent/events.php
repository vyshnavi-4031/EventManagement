<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "12345";
$dbname = "events";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Escape values to prevent SQL injection
$selectedVenue = $conn->real_escape_string($_GET['venue']);
$cost = $conn->real_escape_string($_GET['cost']);
$imagePath = $conn->real_escape_string($_GET['image']);

// Insert values into the database
$sql = "INSERT INTO venues (name, cost, image) VALUES ('$selectedVenue', '$cost', '$imagePath')";

if ($conn->query($sql) === TRUE) {
    echo '<script type="text/javascript">';
    echo 'alert("Record Inserted!");';
    echo 'window.location.href = "ambiance.php";'; // Redirect to another_page
    echo '</script>';
    exit;
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the connection
$conn->close();
?>
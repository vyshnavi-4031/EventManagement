<!DOCTYPE html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Feedback Form</title>
  <style>
    body {
      font-family: sans-serif;
      margin: 0;
      padding: 0;
    }

    .container {
      width: 800px;
      margin: 0 auto;
      padding: 20px;
      border: 1px solid #ccc;
    }

    h1 {
      text-align: center;
      margin-bottom: 20px;
    }

    form {
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    label {
      display: block;
      margin-bottom: 5px;
    }

    input, textarea {
      width: 200px;
      padding: 5px;
      border: 1px solid #ccc;
    }

    textarea {
      height: 100px;
    }

    button {
      padding: 10px 20px;
      background-color: #007bff;
      color: #fff;
      border: none;
      cursor: pointer;
    }
  </style>
</head>
<body>

<div class="container">
  <h1>Suggestion Form</h1>

  <form action="suggestion-data.php" method="POST">
    <label for="name">Your Name:</label>
    <input type="text" id="name" name="name" required>

    <label for="email">Your Email:</label>
    <input type="email" id="email" name="email" required>

    <label for="suggestion">Suggestion:</label>
    <textarea id="suggestion" name="suggestion" required></textarea>

    <button type="submit">Submit Suggestion</button>
  </form>
</div>
</body>
</html>

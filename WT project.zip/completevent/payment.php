<?php
$servername = "localhost";
$username = "root";
$password = "12345";
$dbname = "events";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Assuming you have the venue ID in $_GET['venue_id']

$sql = "SELECT * FROM venues";
$result = $conn->query($sql);
$id = 1;
while ($row = mysqli_fetch_assoc($result)) {
    $id = $row["id"];
}

$sql = "SELECT name, cost, image FROM venues WHERE id ='$id'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $venueName = $row['name'];
    $venueCost = $row['cost'];
    $venueImage = $row['image'];
} else {
    // Handle the case where the venue information is not found
    $venueName = 'Not Found';
    $venueCost = '$0';
    $venueImage = 'No Image';
}
$sql = "SELECT * FROM food WHERE id ='$id'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $foodName = $row['name'];
    $foodCost = $row['cost'];
    $foodImage = $row['image'];
} else {
    // Handle the case where the venue information is not found
    $foodName = 'Not Found';
    $foodCost = '$0';
    $foodImage = 'No Image';
}

$sql = "SELECT name, cost, image FROM ambiance WHERE id ='$id'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $abName = $row['name'];
    $abCost = $row['cost'];
    $abImage = $row['image'];
} else {
    // Handle the case where the venue information is not found
    $abName = 'Not Found';
    $abCost = '$0';
    $abImage = 'No Image';
}

$sql = "SELECT * FROM dt WHERE id ='$id'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $date = $row['event_date'];
    $time = $row['event_time'];
} 

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wedding Planner - Payment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 1em;
            text-align: center;
        }

        section {
            padding: 20px;
        }

        .selected-item {
            margin-bottom: 20px;
        }

        .total-cost {
            font-weight: bold;
        }

        form {
            max-width: 400px;
            margin: 20px auto;
        }

        form input {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
        }

        form button {
            background-color: #333;
            color: #fff;
            border: none;
            padding: 10px;
            cursor: pointer;
        }
    </style>
</head>
<body>

    <header>
        <h1>Payment Processing</h1>
    </header>

    <section>
        <h2>Selected Venue:</h2>
        <?php
            // Check if "venue" key is set in $_GET
            echo "<p>Venue: $venueName</p>";

            // Check if "cost" key is set in $_GET
            echo "<p>Cost: $venueCost</p>";

            // Check if "image" key is set in $_GET
            echo "<p>Image: $venueImage</p>";
        ?>

        <h2>Selected Food:</h2>
        <?php
            // Check if "venue" key is set in $_GET
            echo "<p>food : $foodName</p>";

            // Check if "cost" key is set in $_GET
            echo "<p>Cost: $foodCost</p>";

            // Check if "image" key is set in $_GET
            echo "<p>Image: $foodImage</p>";
        ?>
        <h2>Selected ambiance:</h2>
        <?php
            // Check if "venue" key is set in $_GET
            echo "<p>ambiancename : $abName</p>";

            // Check if "cost" key is set in $_GET
            echo "<p>Cost: $abCost</p>";

            // Check if "image" key is set in $_GET
            echo "<p>Image: $abImage</p>";
        ?>

        <?php
            // Calculate total cost
            $totalCost = intval($venueCost) + intval($foodCost) + intval($abCost);
            echo "<h2>Total Cost: $$totalCost</h2>";
        ?>
         <?php
            // Check if "venue" key is set in $_GET
            echo "<h3>date-time : $date --  $time</h3>";
        ?>
    </section>
    
    <form action="paymentprocess.php" method="POST">
        <input type="text" name="client_name" placeholder="Your Name" required>
        <input type="email" name="client_email" placeholder="Your Email" required>
        <input type="tel" name="client_phone" placeholder="Your Phone" required>
        <input type="hidden" name="venue_name" value="<?php echo "$venueName";?>">
        <input type="hidden" name="venue_cost" value="<?php echo "$venueCost";?>">
        <input type="hidden" name="food_name" value="<?php echo "$foodName";?>">
        <input type="hidden" name="food_cost" value="<?php echo "$foodCost";?>">
        <input type="hidden" name="ab_name" value="<?php echo "$abName";?>">
        <input type="hidden" name="ab_cost" value="<?php echo "$abCost";?>">
        <input type="hidden" name="event_date" value="<?php echo "$date";?>">
        <input type="hidden" name="event_time" value="<?php echo "$time";?>">
        <button type="submit">Proceed to Payment</button>
    </form>

</body>
</html>

<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "12345";
$dbname = "events";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Escape values to prevent SQL injection
$eventDate = $conn->real_escape_string($_POST['event_date']);
$eventTime = $conn->real_escape_string($_POST['event_time']);

// Insert values into the database
$sql = "INSERT INTO dt (event_date, event_time) VALUES ('$eventDate', '$eventTime')";

if ($conn->query($sql) === TRUE) {
    echo '<script type="text/javascript">';
    echo 'alert("Event booked successfully!");';
    echo 'window.location.href = "payment.php";'; 
    echo '</script>';
    exit;
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the connection
$conn->close();
?>

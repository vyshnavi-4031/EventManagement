<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wedding Planner - Select Food</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 1em;
            text-align: center;
        }

        section {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            padding: 20px;
        }

        .Food {
            width: 30%;
            margin: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
            cursor: pointer;
        }

        .Food:hover {
            transform: scale(1.05);
        }

        .Food img {
            width: 100%;
            height: auto;
        }

        button {
            margin-top: 20px;
            padding: 10px;
            background-color: #333;
            color: #fff;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>

    <header>
        <h1>Select Food Package</h1>
    </header>

    <section>
        <form id="FoodForm" action="food_db.php" method="GET" style="display: none;">
            <input type="hidden" id="selectFood" name="food" value="">
            <input type="hidden" id="selectCost" name="cost" value="">
            <input type="hidden" id="selectImage" name="image" value="">
        </form>

        <div class="Food" onclick="selectFood('Package A', 50000, 'photos/bfood1.jpg')">
            <img src="photos/bfood1.jpg" alt="Food A">
            <h3>Food A</h3>
            <p>$50000</p>
        </div>

        <div class="Food" onclick="selectFood('Package B', 70000, 'photos/bfood2.jpg')">
            <img src="photos/bfood2.jpg" alt="Food B">
            <h3>Food B</h3>
            <p>$70000</p>
        </div>

        <div class="Food" onclick="selectFood('Package C', 50000, 'photos/bfood3.jpg')">
            <img src="photos/bfood3.jpg" alt="Food C">
            <h3>Food C</h3>
            <p>$50000</p>
        </div>

        <div class="Food" onclick="selectFood('Package D', 70000, 'photos/bfood4.jpg')">
            <img src="photos/bfood4.jpg" alt="Food D">
            <h3>Food D</h3>
            <p>$70000</p>
        </div>

        <div class="Food" onclick="selectFood('Package E', 50000, 'photos/bfood5.jpg')">
            <img src="photos/bfood5.jpg" alt="Food E">
            <h3>Food E</h3>
            <p>$50000</p>
        </div>

        <div class="Food" onclick="selectFood('Package F', 70000, 'photos/bfood6.jpg')">
            <img src="photos/bfood6.jpg" alt="Food F">
            <h3>Food F</h3>
            <p>$70000</p>
        </div>

    </section>
   <script>
        function selectFood(Food, cost, imagePath) {
            // Set the selected venue, cost, and image path values in the form
            document.getElementById('selectFood').value = Food;
            document.getElementById('selectCost').value = cost;
            document.getElementById('selectImage').value = imagePath;

            // Submit the form to redirect to food.php
            document.getElementById('FoodForm').submit();
        }
    </script>
</body>
</html>

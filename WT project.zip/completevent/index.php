<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Management Website</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 1em;
            text-align: center;
        }

        section {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            padding: 20px;
        }

        .event {
            width: 30%;
            margin: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }

        .event:hover {
            transform: scale(1.05);
        }

        .event img {
            width: 100%;
            height: auto;
        }
    </style>
</head>
<body>

    <header>
        <h1>Event Management</h1>
    </header>

    <section>
        <div class="event" onclick="navigateToEventPage('marriage')">
            <img src="photos/marriagepic.jpg" alt="marriage">
            <h2>Marriage</h2>
        </div>

        <div class="event" onclick="navigateToEventPage('birthday')">
            <img src="photos/birthdaypic1.jpg" alt="conference">
            <h2>Birthday</h2>
        </div>

        <div class="event" onclick="navigateToEventPage('graduation')">
            <img src="photos/graduation.jpg" alt="graduation">
            <h2>Graduation</h2>
        </div>
    </section>

    <script>
        function navigateToEventPage(eventType) {
            // You can define the URLs for each event type and navigate to them here
            switch (eventType) {
                case 'marriage':
                    window.location.href = 'marriage.php';
                    break;
                case 'birthday':
                    window.location.href = 'birthday.php';
                    break;
                case 'graduation':
                    window.location.href = 'graduation.php';
                    break;
                // Add more cases for other event types
            }
        }
    </script>

</body>
</html>
